# Blues Rock Listesi (Bonamassa Tarzı)

Joe Bonamassa'nın o modern, sustain dolu ve "heavy" blues sound'una benzer bir seçki.

## Şarkılar ve Sanatçılar
1. **Kenny Wayne Shepherd** - *Blue on Black*
2. **Gary Clark Jr.** - *Bright Lights*
3. **Eric Gales** - *I Want My Crown (feat. Joe Bonamassa)*
4. **Beth Hart** - *Caught Out in the Rain*
5. **Philip Sayce** - *Out of My Mind*
6. **Walter Trout** - *Say Goodbye to the Blues*
7. **The Marcus King Band** - *The Well*
8. **Samantha Fish** - *Bulletproof*

## Öneri
Eğer Joe'nun o "yüksek gain'li ama net" tonlarını seviyorsan, **Philip Sayce**'e özellikle kulak kabart.
