# 🎸 Solo Proje (Notion Sync)
- Şarkı 1
- Şarkı 2
- Şarkı 3
- Şarkı 4
- Şarkı 5
- Şarkı 6
- Şarkı 7
*(Not: İçerikler sen paylaştıkça buraya senkronize edilecektir.)*
